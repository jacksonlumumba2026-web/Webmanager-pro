# WebManager Pro — Foundation v0.2

A React + TypeScript + Vite starter connected to your Supabase project. This release includes administrator sign-in/sign-up, first-run agency workspace creation, an agency dashboard, client records, website portfolio overview, and Supabase-backed data loading.

## 1. Requirements

- Node.js 20.19+ or 22.12+
- npm
- A GitHub account (for source control and later deployment)

## 2. Run locally

1. Download and extract the project folder.
2. Open the extracted `webmanager-pro` folder.
3. Copy `.env.example` to a new file named `.env`.
4. In `.env`, replace `PASTE_YOUR_SUPABASE_PUBLISHABLE_KEY_HERE` with the **publishable** key from Supabase → Project Settings → API Keys.
5. Open a terminal in the project folder and run:

```bash
npm install
npm run dev
```

6. Open the local URL printed by Vite (usually `http://localhost:5173`).

To create a production build:

```bash
npm run build
```

## 3. Supabase project already provisioned

- Project: WebManager Pro
- Project reference: `fcbmwyseyymygzlcmxar`
- Region: `ap-south-1` (Mumbai)
- Project URL: `https://fcbmwyseyymygzlcmxar.supabase.co`

The database foundation migration has already created these public tables with Row Level Security:

- `profiles`
- `organizations`
- `organization_memberships`
- `clients`
- `websites`
- `activity_logs`

## 4. Upload to GitHub (no ZIP upload required)

GitHub's web interface can accept the extracted files and folders:

1. In GitHub, create a new repository named `webmanager-pro`.
2. Keep it empty (do not add a README or .gitignore, because this folder already includes them).
3. Open the new repository.
4. Choose **Add file → Upload files**.
5. On your phone, extract the ZIP using the Files app or a ZIP extractor.
6. Select the extracted project files and folders, not the ZIP itself. Include hidden files such as `.gitignore` and `.env.example` if your file picker displays them.
7. Do **not** upload `.env`, `node_modules`, or `dist`.
8. Commit the upload.

For a large project, use GitHub Desktop or Git from a computer instead of selecting many files in a mobile browser.

## 5. Deploying on GitHub Pages

This is a Vite single-page application. GitHub Pages can host its built static frontend using a Pages workflow, but the build output (`dist`) must be published by GitHub Actions. Supabase remains the hosted authentication/database backend.

A custom domain can be connected later through GitHub Pages and your DNS provider.

## Security notes

- Only the Supabase publishable key belongs in the frontend `.env`.
- Never use a Supabase `service_role` key or secret key in browser code, GitHub Pages files, or a committed environment file.
- Never commit `.env`.
- The app does not collect or store client passwords.
- The current release is an administrator dashboard foundation, not yet the full source-code editor, credential vault, GitHub OAuth integration, or deployment control plane.
- Before public launch, enable email confirmation as desired, test RLS using separate test accounts, add invite flows and server-side authorization for privileged integrations, and review production security settings.

## Project structure

```text
webmanager-pro/
  src/
    lib/supabase.ts
    App.tsx
    main.tsx
    styles.css
    vite-env.d.ts
  .env.example
  .gitignore
  index.html
  package.json
  tsconfig*.json
  vite.config.ts
  README.md
```
