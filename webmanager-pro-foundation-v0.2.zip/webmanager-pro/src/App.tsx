import { useEffect, useMemo, useState } from 'react'
import type { FormEvent } from 'react'
import { Activity, ArrowUpRight, Bell, BriefcaseBusiness, Building2, Code2, Globe2, LayoutDashboard, LogOut, Plus, Search, Settings, ShieldCheck, Users, X } from 'lucide-react'
import type { Session } from '@supabase/supabase-js'
import { isSupabaseConfigured, supabase } from './lib/supabase'

type Client = { id: string; company_name: string; contact_name: string | null; contact_email: string | null; status: string }
type Website = { id: string; name: string; domain: string | null; status: string; production_url: string | null; deployment_provider: string }

export default function App() {
  const [session, setSession] = useState<Session | null>(null)
  const [authReady, setAuthReady] = useState(!isSupabaseConfigured)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin')
  const [message, setMessage] = useState('')
  const [clients, setClients] = useState<Client[]>([])
  const [websites, setWebsites] = useState<Website[]>([])
  const [workspaceName, setWorkspaceName] = useState('')
  const [workspaceId, setWorkspaceId] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<'overview' | 'clients' | 'websites'>('overview')
  const [search, setSearch] = useState('')
  const [showClientForm, setShowClientForm] = useState(false)
  const [newClient, setNewClient] = useState({ company_name: '', contact_name: '', contact_email: '' })
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!supabase) return
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session)
      setAuthReady(true)
    })
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => setSession(nextSession))
    return () => listener.subscription.unsubscribe()
  }, [])

  useEffect(() => {
    if (session?.user && supabase) void loadWorkspace(session.user.id)
    else { setClients([]); setWebsites([]); setWorkspaceId(null); setWorkspaceName('') }
  }, [session])

  async function loadWorkspace(userId: string) {
    if (!supabase) return
    setLoading(true)
    setMessage('')
    const { data: memberships, error: membershipError } = await supabase
      .from('organization_memberships').select('organization_id, role').eq('user_id', userId).limit(1)
    if (membershipError) { setMessage(membershipError.message); setLoading(false); return }
    if (!memberships?.length) {
      setLoading(false)
      setMessage('Your account is ready. Create your agency workspace to begin.')
      return
    }
    const orgId = memberships[0].organization_id as string
    setWorkspaceId(orgId)
    const [{ data: org }, { data: clientRows }, { data: websiteRows }] = await Promise.all([
      supabase.from('organizations').select('name').eq('id', orgId).single(),
      supabase.from('clients').select('id, company_name, contact_name, contact_email, status').eq('organization_id', orgId).order('created_at', { ascending: false }),
      supabase.from('websites').select('id, name, domain, status, production_url, deployment_provider').eq('organization_id', orgId).order('created_at', { ascending: false }),
    ])
    setWorkspaceName(org?.name ?? 'My Agency')
    setClients((clientRows ?? []) as Client[])
    setWebsites((websiteRows ?? []) as Website[])
    setLoading(false)
  }

  async function handleAuth(event: FormEvent) {
    event.preventDefault()
    if (!supabase) return
    setMessage('')
    const result = authMode === 'signup'
      ? await supabase.auth.signUp({ email, password })
      : await supabase.auth.signInWithPassword({ email, password })
    setMessage(result.error?.message ?? (authMode === 'signup' ? 'Account created. Check your email if confirmation is enabled.' : 'Signed in successfully.'))
  }

  async function createWorkspace(event: FormEvent) {
    event.preventDefault()
    if (!supabase || !session?.user) return
    const cleanName = workspaceName.trim()
    if (cleanName.length < 2) { setMessage('Enter an agency name with at least 2 characters.'); return }
    const slug = cleanName.toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') + '-' + crypto.randomUUID().slice(0, 6)
    setLoading(true)
    const { data: org, error: orgError } = await supabase.from('organizations')
      .insert({ name: cleanName, slug, created_by: session.user.id }).select('id').single()
    if (orgError || !org) { setMessage(orgError?.message ?? 'Could not create workspace.'); setLoading(false); return }
    const { error: membershipError } = await supabase.from('organization_memberships')
      .insert({ organization_id: org.id, user_id: session.user.id, role: 'owner' })
    if (membershipError) setMessage(membershipError.message)
    else { setMessage('Workspace created.'); await loadWorkspace(session.user.id) }
    setLoading(false)
  }

  async function addClient(event: FormEvent) {
    event.preventDefault()
    if (!supabase || !workspaceId) return
    const { error } = await supabase.from('clients').insert({
      organization_id: workspaceId,
      company_name: newClient.company_name.trim(),
      contact_name: newClient.contact_name.trim() || null,
      contact_email: newClient.contact_email.trim() || null,
    })
    if (error) setMessage(error.message)
    else {
      setNewClient({ company_name: '', contact_name: '', contact_email: '' })
      setShowClientForm(false)
      if (session?.user) await loadWorkspace(session.user.id)
    }
  }

  const filteredClients = useMemo(() => clients.filter(c =>
    `${c.company_name} ${c.contact_name ?? ''} ${c.contact_email ?? ''}`.toLowerCase().includes(search.toLowerCase())
  ), [clients, search])

  if (!isSupabaseConfigured) return <SetupScreen />
  if (!authReady) return <div className="loading-screen">Loading WebManager Pro…</div>
  if (!session) return (
    <main className="auth-screen">
      <section className="auth-card">
        <Brand />
        <p className="eyebrow">CLIENT WEBSITE MANAGEMENT</p>
        <h1>{authMode === 'signin' ? 'Welcome back' : 'Create your admin account'}</h1>
        <p className="muted">Manage clients, websites and publishing from one workspace.</p>
        <form onSubmit={handleAuth} className="stack">
          <label>Email address<input type="email" autoComplete="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="you@company.com" /></label>
          <label>Password<input type="password" autoComplete={authMode === 'signup' ? 'new-password' : 'current-password'} minLength={8} required value={password} onChange={e => setPassword(e.target.value)} placeholder="At least 8 characters" /></label>
          <button className="primary full" type="submit">{authMode === 'signin' ? 'Sign in' : 'Create account'}</button>
        </form>
        {message && <p className="notice">{message}</p>}
        <button className="text-button" onClick={() => { setAuthMode(authMode === 'signin' ? 'signup' : 'signin'); setMessage('') }}>
          {authMode === 'signin' ? 'New to WebManager Pro? Create an account' : 'Already registered? Sign in'}
        </button>
      </section>
    </main>
  )

  if (!workspaceId) return (
    <main className="auth-screen">
      <section className="auth-card">
        <Brand />
        <p className="eyebrow">FIRST-TIME SETUP</p>
        <h1>Create your agency workspace</h1>
        <p className="muted">This workspace is where you will organize your clients and their websites.</p>
        <form className="stack" onSubmit={createWorkspace}>
          <label>Agency / business name<input required minLength={2} value={workspaceName} onChange={e => setWorkspaceName(e.target.value)} placeholder="Your agency name" /></label>
          <button className="primary full" disabled={loading} type="submit">{loading ? 'Creating…' : 'Create workspace'}</button>
        </form>
        {message && <p className="notice">{message}</p>}
        <button className="text-button" onClick={() => supabase?.auth.signOut()}><LogOut size={15} /> Sign out</button>
      </section>
    </main>
  )

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <Brand />
        <div className="workspace-switch"><div className="workspace-mark">W</div><div><strong>{workspaceName}</strong><span>Agency workspace</span></div></div>
        <p className="nav-label">WORKSPACE</p>
        <nav>
          <button className={activeTab === 'overview' ? 'nav-item active' : 'nav-item'} onClick={() => setActiveTab('overview')}><LayoutDashboard size={18} /> Overview</button>
          <button className={activeTab === 'clients' ? 'nav-item active' : 'nav-item'} onClick={() => setActiveTab('clients')}><Users size={18} /> Clients <span className="nav-count">{clients.length}</span></button>
          <button className={activeTab === 'websites' ? 'nav-item active' : 'nav-item'} onClick={() => setActiveTab('websites')}><Globe2 size={18} /> Websites <span className="nav-count">{websites.length}</span></button>
        </nav>
        <div className="sidebar-bottom"><button className="nav-item"><Settings size={18} /> Settings</button><div className="user-card"><div className="avatar">{session.user.email?.slice(0, 1).toUpperCase()}</div><div className="user-meta"><strong>Administrator</strong><span>{session.user.email}</span></div><button className="icon-button" title="Sign out" onClick={() => supabase?.auth.signOut()}><LogOut size={17} /></button></div></div>
      </aside>
      <main className="main-area">
        <header className="topbar"><div className="crumb">Workspace <span>/</span> <strong>{activeTab[0].toUpperCase() + activeTab.slice(1)}</strong></div><div className="top-actions"><div className="connection"><span /> Supabase connected</div><button className="icon-button"><Bell size={18} /></button></div></header>
        <div className="page-content">
          {message && <div className="notice inline-notice">{message}<button onClick={() => setMessage('')}><X size={14} /></button></div>}
          {activeTab === 'overview' && <>
            <div className="page-heading"><div><p className="eyebrow">AGENCY CONTROL CENTER</p><h1>Good to see you.</h1><p className="muted">Here is what is happening across your website portfolio.</p></div><button className="primary" onClick={() => { setActiveTab('clients'); setShowClientForm(true) }}><Plus size={17} /> Add client</button></div>
            <section className="stats-grid">
              <Stat icon={<Users />} label="Total clients" value={clients.length} />
              <Stat icon={<Globe2 />} label="Websites managed" value={websites.length} />
              <Stat icon={<Activity />} label="Active websites" value={websites.filter(w => w.status === 'active').length} />
              <Stat icon={<ShieldCheck />} label="Workspace security" value="Protected" />
            </section>
            <div className="content-grid">
              <section className="panel"><div className="panel-heading"><div><h2>Recent websites</h2><p>Your latest managed projects</p></div><button className="link-button" onClick={() => setActiveTab('websites')}>View all <ArrowUpRight size={15}/></button></div>
                {websites.length ? <div className="row-list">{websites.slice(0, 5).map(w => <div className="list-row" key={w.id}><div className="item-icon"><Globe2 size={18}/></div><div className="item-main"><strong>{w.name}</strong><span>{w.domain || w.production_url || 'Domain not connected'}</span></div><Status value={w.status}/></div>)}</div> : <Empty icon={<Globe2/>} title="No websites yet" desc="Add your first website record when you are ready."/>}</section>
              <section className="panel"><div className="panel-heading"><div><h2>Getting started</h2><p>Set up your management workspace</p></div></div><div className="checklist"><div><span className="check done">✓</span><div><strong>Connect your database</strong><p>Supabase project linked</p></div></div><div><span className="check">{clients.length ? '✓' : '2'}</span><div><strong>Add your first client</strong><p>Keep client details in one place</p></div></div><div><span className="check">{websites.length ? '✓' : '3'}</span><div><strong>Register a website</strong><p>Track repository and deployment details</p></div></div></div></section>
            </div>
          </>}
          {activeTab === 'clients' && <><div className="page-heading"><div><p className="eyebrow">RELATIONSHIP MANAGEMENT</p><h1>Clients</h1><p className="muted">Manage the businesses whose websites you look after.</p></div><button className="primary" onClick={() => setShowClientForm(true)}><Plus size={17}/> Add client</button></div>
            <section className="panel"><div className="toolbar"><div className="search-box"><Search size={17}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search clients…"/></div><span className="muted small">{filteredClients.length} clients</span></div>
              {filteredClients.length ? <div className="table-wrap"><table><thead><tr><th>Company</th><th>Contact person</th><th>Email</th><th>Status</th></tr></thead><tbody>{filteredClients.map(c => <tr key={c.id}><td><strong>{c.company_name}</strong></td><td>{c.contact_name || '—'}</td><td>{c.contact_email || '—'}</td><td><Status value={c.status}/></td></tr>)}</tbody></table></div> : <Empty icon={<BriefcaseBusiness/>} title="No clients found" desc="Add a client to start building your portfolio."/>}</section>
          </>}
          {activeTab === 'websites' && <><div className="page-heading"><div><p className="eyebrow">WEBSITE PORTFOLIO</p><h1>Websites</h1><p className="muted">Keep website domains, repositories and publishing destinations organized.</p></div></div><section className="panel">{websites.length ? <div className="table-wrap"><table><thead><tr><th>Website</th><th>Domain</th><th>Deployment</th><th>Status</th></tr></thead><tbody>{websites.map(w => <tr key={w.id}><td><strong>{w.name}</strong></td><td>{w.domain || '—'}</td><td>{w.deployment_provider.replaceAll('_', ' ')}</td><td><Status value={w.status}/></td></tr>)}</tbody></table></div> : <Empty icon={<Code2/>} title="No websites registered" desc="Website creation and repository linking will be added in the next build step."/>}</section></>}
          {loading && <p className="muted small">Refreshing workspace data…</p>}
        </div>
      </main>
      {showClientForm && <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) setShowClientForm(false) }}><section className="modal"><div className="modal-head"><div><p className="eyebrow">NEW RECORD</p><h2>Add a client</h2></div><button className="icon-button" onClick={() => setShowClientForm(false)}><X/></button></div><form className="stack" onSubmit={addClient}><label>Company name<input required value={newClient.company_name} onChange={e => setNewClient({...newClient, company_name: e.target.value})}/></label><label>Contact name<input value={newClient.contact_name} onChange={e => setNewClient({...newClient, contact_name: e.target.value})}/></label><label>Contact email<input type="email" value={newClient.contact_email} onChange={e => setNewClient({...newClient, contact_email: e.target.value})}/></label><button className="primary full" type="submit">Save client</button></form></section></div>}
    </div>
  )
}

function Brand() { return <div className="brand"><div className="brand-icon">W</div><span>WebManager <b>Pro</b></span></div> }
function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string | number }) { return <div className="stat-card"><div className="stat-top"><span>{label}</span><div className="stat-icon">{icon}</div></div><strong>{value}</strong></div> }
function Status({ value }: { value: string }) { return <span className={`status status-${value}`}>{value.replace('_', ' ')}</span> }
function Empty({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) { return <div className="empty-state"><div>{icon}</div><strong>{title}</strong><p>{desc}</p></div> }
function SetupScreen() { return <main className="auth-screen"><section className="auth-card"><Brand/><p className="eyebrow">ONE QUICK SETUP STEP</p><h1>Connect your Supabase project</h1><p className="muted">Create a local <code>.env</code> file using the values in <code>.env.example</code>. Paste your Supabase publishable key in the file, then restart the app.</p><div className="setup-note"><strong>Project URL</strong><code>https://fcbmwyseyymygzlcmxar.supabase.co</code><p>Find the publishable key in Supabase: Project Settings → API Keys → Publishable key.</p></div><p className="muted small">Never paste a service-role or secret key into this frontend.</p></section></main> }
