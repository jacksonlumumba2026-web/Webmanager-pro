import { useEffect, useState } from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import { supabase, isSupabaseConfigured } from "./lib/supabase";
import type { Session } from "@supabase/supabase-js";
import { Login } from "./pages/Login";
import { Dashboard } from "./pages/Dashboard";
import { Clients } from "./pages/Clients";
import { Websites } from "./pages/Websites";
import { Shell } from "./components/Shell";
import { SetupWorkspace } from "./pages/SetupWorkspace";

export default function App() {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [hasWorkspace, setHasWorkspace] = useState<boolean | null>(null);

  useEffect(() => {
    if (!isSupabaseConfigured) { setLoading(false); return; }
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoading(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
      setHasWorkspace(null);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    let alive = true;
    async function checkWorkspace() {
      if (!session?.user) { setHasWorkspace(null); return; }
      const { data, error } = await supabase.from("memberships").select("id").limit(1);
      if (alive) setHasWorkspace(!error && Boolean(data?.length));
    }
    checkWorkspace();
    return () => { alive = false; };
  }, [session]);

  if (!isSupabaseConfigured) return <div className="setup-screen"><div className="setup-card"><div className="brand-mark">W</div><h1>Connect your Supabase project</h1><p>Add your project URL and publishable/anon key to the <code>.env</code> file. See the README for setup instructions.</p></div></div>;
  if (loading || (session && hasWorkspace === null)) return <div className="loading-screen">Loading WebManager Pro…</div>;
  if (!session) return <Login />;
  if (!hasWorkspace) return <SetupWorkspace onCreated={() => setHasWorkspace(true)} />;

  return (
    <Shell onSignOut={() => supabase.auth.signOut()}>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/clients" element={<Clients />} />
        <Route path="/websites" element={<Websites />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Shell>
  );
}
