import { NavLink } from "react-router-dom";
import { LayoutDashboard, Users, Globe2, Settings, LogOut, ShieldCheck, Menu } from "lucide-react";
import { useState } from "react";

export function Shell({ children, onSignOut }: { children: React.ReactNode; onSignOut: () => void }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  const links = [
    { to: "/", label: "Overview", icon: LayoutDashboard, end: true },
    { to: "/clients", label: "Clients", icon: Users },
    { to: "/websites", label: "Websites", icon: Globe2 },
  ];
  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileOpen ? "sidebar-open" : ""}`}>
        <div className="brand"><div className="brand-mark">W</div><div><strong>WebManager</strong><span>PRO</span></div></div>
        <div className="workspace-label">WORKSPACE</div>
        <nav>{links.map(({ to, label, icon: Icon, end }) => <NavLink key={to} to={to} end={end} onClick={() => setMobileOpen(false)} className={({ isActive }) => isActive ? "nav-link active" : "nav-link"}><Icon size={18}/>{label}</NavLink>)}</nav>
        <div className="sidebar-bottom">
          <div className="secure-note"><ShieldCheck size={17}/><div><b>Workspace protected</b><small>Access controls enabled</small></div></div>
          <button className="nav-link signout" onClick={onSignOut}><LogOut size={18}/>Sign out</button>
        </div>
      </aside>
      <main className="main-area">
        <header className="topbar"><button className="mobile-menu" onClick={() => setMobileOpen(!mobileOpen)}><Menu size={20}/></button><div className="breadcrumb">Workspace <span>/</span> Administration</div><div className="topbar-right"><span className="admin-pill">Administrator</span><div className="avatar">A</div></div></header>
        <div className="page-content">{children}</div>
        <footer className="footer"><span>WebManager Pro · Foundation v0.1</span><span><Settings size={13}/> Secure client management</span></footer>
      </main>
    </div>
  );
}
