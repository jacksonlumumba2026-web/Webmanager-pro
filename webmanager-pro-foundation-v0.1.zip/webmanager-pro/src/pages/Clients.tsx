import { FormEvent, useEffect, useState } from "react";
import { Plus, Search, Users, X } from "lucide-react";
import { supabase } from "../lib/supabase";
import type { Client } from "../types";

export function Clients() {
  const [items, setItems] = useState<Client[]>([]);
  const [orgId, setOrgId] = useState("");
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [search, setSearch] = useState("");
  const [business, setBusiness] = useState("");
  const [contact, setContact] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  async function load() {
    const { data: m } = await supabase.from("memberships").select("organization_id").limit(1).single();
    if (m?.organization_id) {
      setOrgId(m.organization_id);
      const { data } = await supabase.from("clients").select("*").eq("organization_id", m.organization_id).order("created_at", { ascending: false });
      setItems((data || []) as Client[]);
    }
    setLoading(false);
  }
  useEffect(() => { load(); }, []);
  async function submit(e: FormEvent) {
    e.preventDefault(); setSaving(true); setError("");
    const { error: insertError } = await supabase.from("clients").insert({
      organization_id: orgId, business_name: business.trim(), contact_name: contact.trim() || null,
      email: email.trim() || null, phone: phone.trim() || null
    });
    if (insertError) setError(insertError.message);
    else { setModal(false); setBusiness(""); setContact(""); setEmail(""); setPhone(""); await load(); }
    setSaving(false);
  }
  const filtered = items.filter(c => `${c.business_name} ${c.contact_name || ""} ${c.email || ""}`.toLowerCase().includes(search.toLowerCase()));
  return <div className="page"><div className="page-heading"><div><div className="eyebrow">RELATIONSHIPS</div><h1>Clients</h1><p>Manage the businesses and people you work with.</p></div><button className="primary-btn" onClick={() => setModal(true)}><Plus size={17}/> Add client</button></div>
    <div className="toolbar"><div className="search-box"><Search size={17}/><input placeholder="Search clients…" value={search} onChange={e => setSearch(e.target.value)}/></div><span className="result-count">{items.length} client{items.length === 1 ? "" : "s"}</span></div>
    <section className="panel">{loading ? <div className="empty-state">Loading clients…</div> : filtered.length ? <div className="table-wrap"><table><thead><tr><th>BUSINESS</th><th>CONTACT PERSON</th><th>EMAIL</th><th>PHONE</th><th>STATUS</th></tr></thead><tbody>{filtered.map(c => <tr key={c.id}><td><div className="client-cell"><div className="client-avatar">{c.business_name.slice(0,1).toUpperCase()}</div><b>{c.business_name}</b></div></td><td>{c.contact_name || "—"}</td><td>{c.email || "—"}</td><td>{c.phone || "—"}</td><td><span className={`status ${c.status}`}>{c.status}</span></td></tr>)}</tbody></table></div> : <div className="empty-state"><Users size={28}/><b>{search ? "No matching clients" : "Your client list is empty"}</b><span>{search ? "Try a different search." : "Add your first client to begin building your portfolio."}</span>{!search && <button className="text-link" onClick={() => setModal(true)}>Add your first client</button>}</div>}</section>
    {modal && <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) setModal(false); }}><div className="modal"><div className="modal-head"><div><h2>Add a client</h2><p>Create a client record in your workspace.</p></div><button className="icon-btn" onClick={() => setModal(false)}><X size={19}/></button></div><form onSubmit={submit}><label>Business name *</label><input className="plain-input" required value={business} onChange={e => setBusiness(e.target.value)} placeholder="e.g. Acme Builders"/><label>Contact person</label><input className="plain-input" value={contact} onChange={e => setContact(e.target.value)} placeholder="Full name"/><label>Email address</label><input className="plain-input" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="client@example.com"/><label>Phone number</label><input className="plain-input" value={phone} onChange={e => setPhone(e.target.value)} placeholder="+254…"/>{error && <div className="error-box">{error}</div>}<div className="modal-actions"><button type="button" className="secondary-btn" onClick={() => setModal(false)}>Cancel</button><button className="primary-btn" disabled={saving}>{saving ? "Saving…" : "Save client"}</button></div></form></div></div>}
  </div>;
}
