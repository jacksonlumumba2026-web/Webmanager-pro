import { FormEvent, useState } from "react";
import { supabase } from "../lib/supabase";

export function SetupWorkspace({ onCreated }: { onCreated: () => void }) {
  const [name, setName] = useState("My Web Development Business");
  const [slug, setSlug] = useState("my-web-business");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setError("");
    const { error: rpcError } = await supabase.rpc("bootstrap_organization", { org_name: name, org_slug: slug });
    if (rpcError) setError(rpcError.message);
    else onCreated();
    setBusy(false);
  }
  return <div className="auth-screen"><div className="auth-card"><div className="brand-mark">W</div><h1>Create your workspace</h1><p>Set up the business workspace that will manage your clients and websites.</p><form onSubmit={submit}><label>Business / workspace name</label><input className="plain-input" value={name} onChange={e => setName(e.target.value)} required/><label>Workspace URL key</label><input className="plain-input" value={slug} onChange={e => setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "-"))} required/><small className="muted">Use 3–40 lowercase letters, numbers or hyphens.</small>{error && <div className="error-box">{error}</div>}<button className="primary-btn full" disabled={busy}>{busy ? "Creating…" : "Create workspace"}</button></form></div></div>;
}
