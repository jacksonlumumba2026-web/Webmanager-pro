import { FormEvent, useEffect, useState } from "react";
import { Plus, Globe2, X, ExternalLink } from "lucide-react";
import { supabase } from "../lib/supabase";
import type { Client, Website } from "../types";

export function Websites() {
  const [items, setItems] = useState<Website[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [orgId, setOrgId] = useState("");
  const [loading, setLoading] = useState(true);
  const [modal, setModal] = useState(false);
  const [name, setName] = useState("");
  const [domain, setDomain] = useState("");
  const [clientId, setClientId] = useState("");
  const [provider, setProvider] = useState<"github_pages" | "truehost" | "other">("github_pages");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  async function load() {
    const { data: m } = await supabase.from("memberships").select("organization_id").limit(1).single();
    if (m?.organization_id) {
      setOrgId(m.organization_id);
      const [{ data: w }, { data: c }] = await Promise.all([
        supabase.from("websites").select("*, clients(business_name)").eq("organization_id", m.organization_id).order("created_at", { ascending: false }),
        supabase.from("clients").select("*").eq("organization_id", m.organization_id).order("business_name")
      ]);
      setItems((w || []) as Website[]); setClients((c || []) as Client[]);
    }
    setLoading(false);
  }
  useEffect(() => { load(); }, []);
  async function submit(e: FormEvent) {
    e.preventDefault(); setSaving(true); setError("");
    const { error: insertError } = await supabase.from("websites").insert({
      organization_id: orgId, client_id: clientId, name: name.trim(),
      domain: domain.trim() || null, live_url: domain.trim() ? `https://${domain.trim()}` : null,
      hosting_provider: provider, status: "draft"
    });
    if (insertError) setError(insertError.message);
    else { setModal(false); setName(""); setDomain(""); setClientId(""); await load(); }
    setSaving(false);
  }
  return <div className="page"><div className="page-heading"><div><div className="eyebrow">PORTFOLIO</div><h1>Websites</h1><p>Register and keep track of your clients' websites.</p></div><button className="primary-btn" onClick={() => setModal(true)}><Plus size={17}/> Add website</button></div>
    <section className="panel">{loading ? <div className="empty-state">Loading websites…</div> : items.length ? <div className="table-wrap"><table><thead><tr><th>WEBSITE</th><th>CLIENT</th><th>HOSTING</th><th>STATUS</th><th>LINK</th></tr></thead><tbody>{items.map(w => <tr key={w.id}><td><div className="client-cell"><div className="site-icon"><Globe2 size={17}/></div><div><b>{w.name}</b><div className="muted">{w.domain || "Domain not set"}</div></div></div></td><td>{w.clients?.business_name || clients.find(c => c.id === w.client_id)?.business_name || "—"}</td><td>{w.hosting_provider.replace("_", " ")}</td><td><span className={`status ${w.status}`}>{w.status}</span></td><td>{w.live_url ? <a className="table-link" href={w.live_url} target="_blank" rel="noreferrer">Visit <ExternalLink size={13}/></a> : "—"}</td></tr>)}</tbody></table></div> : <div className="empty-state"><Globe2 size={28}/><b>No websites registered</b><span>Add a website and assign it to one of your clients.</span><button className="text-link" onClick={() => setModal(true)}>Add your first website</button></div>}</section>
    {modal && <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) setModal(false); }}><div className="modal"><div className="modal-head"><div><h2>Register a website</h2><p>Connect a website record to a client.</p></div><button className="icon-btn" onClick={() => setModal(false)}><X size={19}/></button></div><form onSubmit={submit}><label>Website name *</label><input className="plain-input" required value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Company website"/><label>Client *</label><select className="plain-input" required value={clientId} onChange={e => setClientId(e.target.value)}><option value="">Select a client</option>{clients.map(c => <option key={c.id} value={c.id}>{c.business_name}</option>)}</select><label>Domain</label><input className="plain-input" value={domain} onChange={e => setDomain(e.target.value.replace(/^https?:\/\//, "").replace(/\/$/, ""))} placeholder="example.co.ke"/><label>Hosting provider</label><select className="plain-input" value={provider} onChange={e => setProvider(e.target.value as typeof provider)}><option value="github_pages">GitHub Pages</option><option value="truehost">Truehost</option><option value="other">Other</option></select>{error && <div className="error-box">{error}</div>}<div className="modal-actions"><button type="button" className="secondary-btn" onClick={() => setModal(false)}>Cancel</button><button className="primary-btn" disabled={saving || !clients.length}>{saving ? "Saving…" : "Save website"}</button></div>{!clients.length && <small className="muted">Add a client before registering a website.</small>}</form></div></div>}
  </div>;
}
