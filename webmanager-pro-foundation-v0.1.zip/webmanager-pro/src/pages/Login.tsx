import { FormEvent, useState } from "react";
import { LockKeyhole, Mail } from "lucide-react";
import { supabase } from "../lib/supabase";

export function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function submit(e: FormEvent) {
    e.preventDefault(); setBusy(true); setError("");
    const { error: authError } = await supabase.auth.signInWithPassword({ email, password });
    if (authError) setError(authError.message);
    setBusy(false);
  }
  return <div className="auth-screen"><div className="auth-card"><div className="auth-brand"><div className="brand-mark">W</div><div><b>WebManager Pro</b><small>WEBSITE MANAGEMENT PLATFORM</small></div></div><div className="auth-heading"><h1>Welcome back</h1><p>Sign in to manage your clients and websites.</p></div><form onSubmit={submit}><label>Email address</label><div className="input-wrap"><Mail size={17}/><input type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="you@company.com"/></div><label>Password</label><div className="input-wrap"><LockKeyhole size={17}/><input type="password" required value={password} onChange={e => setPassword(e.target.value)} placeholder="Enter your password"/></div>{error && <div className="error-box">{error}</div>}<button className="primary-btn full" disabled={busy}>{busy ? "Signing in…" : "Sign in"}</button></form><div className="auth-foot">Access is restricted to invited and authorized users.</div></div><div className="auth-copyright">© {new Date().getFullYear()} WebManager Pro</div></div>;
}
