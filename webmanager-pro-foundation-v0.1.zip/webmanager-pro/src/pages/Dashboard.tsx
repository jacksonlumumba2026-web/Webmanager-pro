import { useEffect, useState } from "react";
import { Users, Globe2, Activity, ArrowUpRight, Plus, Clock3 } from "lucide-react";
import { Link } from "react-router-dom";
import { supabase } from "../lib/supabase";
import type { Client, Website } from "../types";

export function Dashboard() {
  const [clients, setClients] = useState<Client[]>([]);
  const [websites, setWebsites] = useState<Website[]>([]);
  const [clientCount, setClientCount] = useState(0);
  const [websiteCount, setWebsiteCount] = useState(0);
  const [activeWebsiteCount, setActiveWebsiteCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [workspace, setWorkspace] = useState("Your workspace");
  useEffect(() => {
    async function load() {
      const { data: membership } = await supabase.from("memberships").select("organization_id").limit(1).single();
      if (membership?.organization_id) {
        const [{ data: c }, { data: w }, { data: org }, { count: cc }, { count: wc }, { count: ac }] = await Promise.all([
          supabase.from("clients").select("*").eq("organization_id", membership.organization_id).order("created_at", { ascending: false }).limit(5),
          supabase.from("websites").select("*, clients(business_name)").eq("organization_id", membership.organization_id).order("created_at", { ascending: false }).limit(5),
          supabase.from("organizations").select("name").eq("id", membership.organization_id).single(),
          supabase.from("clients").select("id", { count: "exact", head: true }).eq("organization_id", membership.organization_id),
          supabase.from("websites").select("id", { count: "exact", head: true }).eq("organization_id", membership.organization_id),
          supabase.from("websites").select("id", { count: "exact", head: true }).eq("organization_id", membership.organization_id).eq("status", "active")
        ]);
        setClients((c || []) as Client[]); setWebsites((w || []) as Website[]);
        setClientCount(cc || 0); setWebsiteCount(wc || 0); setActiveWebsiteCount(ac || 0);
        if (org?.name) setWorkspace(org.name);
      }
      setLoading(false);
    }
    load();
  }, []);
  return <div className="page">
    <div className="page-heading"><div><div className="eyebrow">OVERVIEW</div><h1>Good day, Administrator</h1><p>Here’s what’s happening across {workspace}.</p></div><Link className="primary-btn" to="/clients"><Plus size={17}/> Add client</Link></div>
    <div className="stat-grid">
      <Stat icon={<Users/>} label="Total clients" value={loading ? "—" : String(clientCount)} note="Registered client records" tone="blue"/>
      <Stat icon={<Globe2/>} label="Websites" value={loading ? "—" : String(websiteCount)} note="Registered website records" tone="green"/>
      <Stat icon={<Activity/>} label="Active websites" value={loading ? "—" : String(activeWebsiteCount)} note="Currently marked active" tone="purple"/>
      <Stat icon={<Clock3/>} label="Pending actions" value="—" note="Deployment workflow coming soon" tone="orange"/>
    </div>
    <div className="content-grid">
      <section className="panel"><div className="panel-heading"><div><h2>Recent clients</h2><p>Your newest client records</p></div><Link to="/clients" className="text-link">View all <ArrowUpRight size={14}/></Link></div>
        {loading ? <div className="empty-state">Loading clients…</div> : clients.length ? <div className="table-wrap"><table><thead><tr><th>BUSINESS</th><th>CONTACT</th><th>STATUS</th></tr></thead><tbody>{clients.slice(0,5).map(c => <tr key={c.id}><td><b>{c.business_name}</b></td><td>{c.contact_name || c.email || "—"}</td><td><span className={`status ${c.status}`}>{c.status}</span></td></tr>)}</tbody></table></div> : <div className="empty-state"><Users size={26}/><b>No clients yet</b><span>Add your first client to get started.</span><Link to="/clients" className="text-link">Add a client</Link></div>}
      </section>
      <section className="panel"><div className="panel-heading"><div><h2>Website portfolio</h2><p>Recently registered websites</p></div><Link to="/websites" className="text-link">View all <ArrowUpRight size={14}/></Link></div>
        {loading ? <div className="empty-state">Loading websites…</div> : websites.length ? <div className="simple-list">{websites.slice(0,5).map(w => <div className="site-row" key={w.id}><div className="site-icon"><Globe2 size={18}/></div><div className="site-info"><b>{w.name}</b><span>{w.domain || "Domain not set"}</span></div><span className={`status ${w.status}`}>{w.status}</span></div>)}</div> : <div className="empty-state"><Globe2 size={26}/><b>No websites registered</b><span>Register a client's website to see it here.</span><Link to="/websites" className="text-link">Add a website</Link></div>}
      </section>
    </div>
    <section className="quick-panel"><div><div className="eyebrow">NEXT STEP</div><h2>Build your client workspace</h2><p>Register your first client and add their website. Client invitations and source-code management will be added in upcoming releases.</p></div><Link to="/clients" className="secondary-btn">Manage clients <ArrowUpRight size={16}/></Link></section>
  </div>;
}
function Stat({ icon, label, value, note, tone }: { icon: React.ReactNode; label: string; value: string; note: string; tone: string }) {
  return <div className="stat-card"><div className={`stat-icon ${tone}`}>{icon}</div><div className="stat-label">{label}</div><div className="stat-value">{value}</div><div className="stat-note">{note}</div></div>;
}
