-- WebManager Pro foundation schema.
-- Run in a new Supabase project. Review and test policies before production.

create extension if not exists pgcrypto;

create type public.member_role as enum ('owner', 'admin', 'staff', 'client');
create type public.website_status as enum ('draft', 'active', 'paused', 'archived');
create type public.hosting_provider as enum ('github_pages', 'truehost', 'other');

create table public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  logo_url text,
  created_by uuid not null references auth.users(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.clients (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid references auth.users(id) on delete set null,
  business_name text not null,
  contact_name text,
  email text,
  phone text,
  notes text,
  status text not null default 'active' check (status in ('active','pending','inactive')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, email)
);

create table public.memberships (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.member_role not null default 'client',
  client_id uuid references public.clients(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (organization_id, user_id),
  check ((role = 'client' and client_id is not null) or (role <> 'client' and client_id is null))
);

create table public.websites (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  client_id uuid not null references public.clients(id) on delete cascade,
  name text not null,
  domain text,
  live_url text,
  hosting_provider public.hosting_provider not null default 'other',
  repository_owner text,
  repository_name text,
  repository_id text,
  repository_mode text check (repository_mode in ('agency_managed','client_owned')),
  status public.website_status not null default 'draft',
  description text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.activity_logs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  actor_user_id uuid references auth.users(id) on delete set null,
  action text not null,
  resource_type text,
  resource_id uuid,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index clients_org_idx on public.clients(organization_id);
create index memberships_user_idx on public.memberships(user_id);
create index websites_org_idx on public.websites(organization_id);
create index websites_client_idx on public.websites(client_id);
create index activity_org_created_idx on public.activity_logs(organization_id, created_at desc);

-- Keep profile records in sync with Auth users.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name', ''))
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Membership helpers. SECURITY DEFINER avoids recursive RLS checks on memberships.
create or replace function public.is_org_member(target_org uuid)
returns boolean
language sql stable security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.memberships m
    where m.organization_id = target_org and m.user_id = (select auth.uid())
  );
$$;

create or replace function public.is_org_admin(target_org uuid)
returns boolean
language sql stable security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.memberships m
    where m.organization_id = target_org
      and m.user_id = (select auth.uid())
      and m.role in ('owner','admin','staff')
  );
$$;

create or replace function public.can_manage_members(target_org uuid)
returns boolean
language sql stable security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.memberships m
    where m.organization_id = target_org
      and m.user_id = (select auth.uid())
      and m.role in ('owner','admin')
  );
$$;

create or replace function public.can_access_client(target_client uuid)
returns boolean
language sql stable security definer
set search_path = ''
as $$
  select exists (
    select 1
    from public.clients c
    join public.memberships m on m.organization_id = c.organization_id
    where c.id = target_client
      and m.user_id = (select auth.uid())
      and (m.role in ('owner','admin','staff') or (m.role = 'client' and m.client_id = c.id))
  );
$$;

-- First-run workspace creation. A user can bootstrap only one initial workspace.
create or replace function public.bootstrap_organization(org_name text, org_slug text)
returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  new_org_id uuid;
  current_user_id uuid := auth.uid();
begin
  if current_user_id is null then
    raise exception 'Authentication required';
  end if;

  if exists (select 1 from public.memberships where user_id = current_user_id) then
    raise exception 'This account already belongs to a workspace';
  end if;

  if length(trim(coalesce(org_name, ''))) < 2 then
    raise exception 'Workspace name must contain at least 2 characters';
  end if;

  if org_slug !~ '^[a-z0-9][a-z0-9-]{1,38}[a-z0-9]$' then
    raise exception 'Workspace URL key must be 3-40 lowercase letters, numbers or hyphens';
  end if;

  insert into public.organizations (name, slug, created_by)
  values (trim(org_name), org_slug, current_user_id)
  returning id into new_org_id;

  insert into public.memberships (organization_id, user_id, role)
  values (new_org_id, current_user_id, 'owner');

  return new_org_id;
end;
$$;

revoke all on function public.bootstrap_organization(text, text) from public;
grant execute on function public.bootstrap_organization(text, text) to authenticated;

-- RLS
alter table public.organizations enable row level security;
alter table public.profiles enable row level security;
alter table public.clients enable row level security;
alter table public.memberships enable row level security;
alter table public.websites enable row level security;
alter table public.activity_logs enable row level security;

create policy "Members can view their organizations"
on public.organizations for select to authenticated
using (public.is_org_member(id));

create policy "Owners and admins can update organization"
on public.organizations for update to authenticated
using (public.is_org_admin(id))
with check (public.is_org_admin(id));

create policy "Users can view own profile"
on public.profiles for select to authenticated
using (id = (select auth.uid()));

create policy "Users can update own profile"
on public.profiles for update to authenticated
using (id = (select auth.uid()))
with check (id = (select auth.uid()));

create policy "Staff can view organization clients"
on public.clients for select to authenticated
using (public.is_org_admin(organization_id));

create policy "Clients can view their own client record"
on public.clients for select to authenticated
using (user_id = (select auth.uid()));

create policy "Staff can create clients"
on public.clients for insert to authenticated
with check (public.is_org_admin(organization_id));

create policy "Staff can update clients"
on public.clients for update to authenticated
using (public.is_org_admin(organization_id))
with check (public.is_org_admin(organization_id));

create policy "Staff can delete clients"
on public.clients for delete to authenticated
using (public.is_org_admin(organization_id));

create policy "Members can view own membership and staff can view org memberships"
on public.memberships for select to authenticated
using (user_id = (select auth.uid()) or public.is_org_admin(organization_id));

create policy "Owners and admins can add memberships"
on public.memberships for insert to authenticated
with check (
  public.can_manage_members(organization_id)
  and (role <> 'owner' or exists (
    select 1 from public.memberships own
    where own.organization_id = memberships.organization_id
      and own.user_id = (select auth.uid())
      and own.role = 'owner'
  ))
);

create policy "Owners can remove memberships"
on public.memberships for delete to authenticated
using (
  exists (
    select 1 from public.memberships own
    where own.organization_id = memberships.organization_id
      and own.user_id = (select auth.uid())
      and own.role = 'owner'
  )
);

create policy "Staff can view organization websites"
on public.websites for select to authenticated
using (public.is_org_admin(organization_id));

create policy "Clients can view assigned websites"
on public.websites for select to authenticated
using (public.can_access_client(client_id));

create policy "Staff can create websites"
on public.websites for insert to authenticated
with check (public.is_org_admin(organization_id) and public.can_access_client(client_id));

create policy "Staff can update websites"
on public.websites for update to authenticated
using (public.is_org_admin(organization_id))
with check (public.is_org_admin(organization_id) and public.can_access_client(client_id));

create policy "Staff can delete websites"
on public.websites for delete to authenticated
using (public.is_org_admin(organization_id));

create policy "Members can view activity logs"
on public.activity_logs for select to authenticated
using (public.is_org_member(organization_id));

create policy "Staff can insert activity logs"
on public.activity_logs for insert to authenticated
with check (public.is_org_admin(organization_id) and actor_user_id = (select auth.uid()));

-- Limit direct grants to the intended application roles.
grant usage on schema public to authenticated;
grant select, update on public.profiles to authenticated;
grant select, update on public.organizations to authenticated;
grant select, insert, update, delete on public.clients to authenticated;
grant select, insert, delete on public.memberships to authenticated;
grant select, insert, update, delete on public.websites to authenticated;
grant select, insert on public.activity_logs to authenticated;
